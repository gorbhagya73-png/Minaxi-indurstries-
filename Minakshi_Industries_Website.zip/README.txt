Minakshi Industries website

1. Put the bottle image you uploaded into this folder.
2. Rename it exactly: bhagya-water-bottle.jpg
3. Open index.html in Chrome.

The website is in English and includes Home, About Us, Products, Why Choose Us and Contact sections.
